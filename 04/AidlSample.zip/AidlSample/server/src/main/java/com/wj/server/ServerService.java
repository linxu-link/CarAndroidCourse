package com.wj.server;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

public class ServerService extends Service {

    private static final String TAG = "ServerService";

    private CalculatorBinder mCalculatorBinder;

    public ServerService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startServiceForeground();
    }

    @Override
    public IBinder onBind(Intent intent) {
        if (mCalculatorBinder == null) {
            mCalculatorBinder = new CalculatorBinder(this);
        }
        return mCalculatorBinder;
    }

    private static final String CHANNEL_ID_STRING = "com.example.server.service";
    private static final int CHANNEL_ID = 0x11;

    private void startServiceForeground() {
        NotificationManager notificationManager = (NotificationManager)
                getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel;
        channel = new NotificationChannel(CHANNEL_ID_STRING, getString(R.string.app_name),
                NotificationManager.IMPORTANCE_LOW);
        notificationManager.createNotificationChannel(channel);
        Notification notification = new Notification.Builder(getApplicationContext(),
                CHANNEL_ID_STRING).build();
        startForeground(CHANNEL_ID, notification);
    }

}