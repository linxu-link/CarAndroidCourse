package com.wj.standardapp;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

public class MainActivity extends AppCompatActivity {
    private AudioDataLoader mAudioDataLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 在MVVM架构下应该放在ViewModel中调用
        mAudioDataLoader = new AudioDataLoader();

        mAudioDataLoader.play();
        mAudioDataLoader.getDuration().observe(this, new Observer<Long>() {
            @Override
            public void onChanged(final Long value) {
                Log.i("MainActivity", "onChanged: " + value);
            }
        });

    }
}