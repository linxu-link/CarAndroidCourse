package com.wj.standardapp;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.wj.standardsdk.Sdk;
import com.wj.standardsdk.audio.AudioManager;
import com.wj.standardsdk.base.SdkBase;

import java.util.concurrent.CountDownLatch;

/**
 * 用于加载音频数据的DataLoader.
 * <p>
 * 在MVVM架构中属于 Model 层的组成部分之一.
 *
 * @author linxu_link
 * @version 1.0
 */
public class AudioDataLoader {

    private Sdk mSdk;
    private AudioManager mAudioManager;
    // 同步锁。将异步的Service的连接，改为同步的。
    private CountDownLatch mAudioManagerReady;

    public AudioDataLoader() {
        mAudioManagerReady = new CountDownLatch(1);
        mSdk = Sdk.get(new SdkBase.SdkServiceLifecycleListener<Sdk>() {
            @Override
            public void onLifecycleChanged(@NonNull final Sdk sdk, final boolean ready) {
                if (ready) {
                    mAudioManager = sdk.getService(AudioManager.class);
                    mAudioManager.registerAudioCallback(mAudioCallback);
                    mAudioManagerReady.countDown();
                } else {
                    if (mAudioManagerReady.getCount() <= 0) {
                        mAudioManagerReady = new CountDownLatch(1);
                    }
                    mAudioManager = null;
                    // 重新连接
                    sdk.connect();
                }
            }
        });
    }

    private final AudioManager.AudioCallback mAudioCallback = new AudioManager.AudioCallback() {
        @Override
        public void onAudioData(final byte[] data, final int length) {

        }
    };

    public void play() {
        // 实际应该放入线程池中执行
        new Thread(() -> {
            try {
                mAudioManagerReady.await();
            } catch (InterruptedException e) {
                return;
            }
            mAudioManager.play();
            Log.i("TAG", "play 执行完毕");
        }).start();
    }

    private MutableLiveData<Long> mDurationData;

    public LiveData<Long> getDuration() {
        // 实际应该放入线程池中执行
        new Thread(() -> {
            try {
                mAudioManagerReady.await();
            } catch (InterruptedException e) {
                getDurationData().postValue(0L);
            }
            getDurationData().postValue(mAudioManager.getDuration());
        }).start();
        return getDurationData();
    }

    public void release() {
        mAudioManager.unregisterAudioCallback(mAudioCallback);
        mSdk.disconnect();
        mSdk = null;
        mAudioManager = null;
    }

    private MutableLiveData<Long> getDurationData() {
        if (mDurationData == null) {
            mDurationData = new MutableLiveData<>();
        }
        return mDurationData;
    }

}
