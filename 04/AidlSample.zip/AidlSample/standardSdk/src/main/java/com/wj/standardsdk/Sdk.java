package com.wj.standardsdk;

import androidx.annotation.NonNull;

import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.Nullable;

import com.wj.standardsdk.audio.AudioManager;
import com.wj.standardsdk.audio.InfoManager;
import com.wj.standardsdk.base.SdkBase;
import com.wj.standardsdk.base.SdkManagerBase;

import java.util.HashMap;

/**
 * Sdk 是一个管理类，用于管理服务端的各种功能，包括音频、信息等。
 *
 * @author linxu_link
 * @version 1.0
 */
public class Sdk extends SdkBase<ISdk> {

    public static final String PERMISSION_AUDIO = "com.wj.standardsdk.permission.AUDIO";

    private static final String SERVICE_PACKAGE = "com.wj.standardserver";
    private static final String SERVICE_CLASS = "com.wj.standardserver.StandardService";
    private static final String SERVICE_ACTION = "android.intent.action.STANDARD_SERVICE";

    public static final int SERVICE_AUDIO = 0x1001;
    public static final int SERVICE_INFO = 0x1002;

    private static final long SERVICE_BIND_RETRY_INTERVAL_MS = 500;
    private static final long SERVICE_BIND_MAX_RETRY = 100;

    /**
     * 创建一个 Manager 对象
     * <p>
     * 是否需要设定为单例，由开发者自行决定。
     *
     * @param context  上下文
     * @param handler  用于处理服务端回调的 Handler
     * @param listener 用于监听服务端生命周期的 Listener
     * @return SdkASyncManager
     */
    public static Sdk get(Context context, Handler handler, SdkServiceLifecycleListener<Sdk> listener) {
        return new Sdk(context, handler, listener);
    }

    public static Sdk get() {
        return new Sdk(null, null, null);
    }

    public static Sdk get(Context context) {
        return new Sdk(context, null, null);
    }

    public static Sdk get(Handler handler) {
        return new Sdk(null, handler, null);
    }

    public static Sdk get(SdkServiceLifecycleListener<Sdk> listener) {
        return new Sdk(null, null, listener);
    }

    public Sdk(@Nullable final Context context, @Nullable final Handler handler, @Nullable final SdkServiceLifecycleListener<Sdk> listener) {
        super(context, handler, listener);
    }

    @Override
    protected String getServicePackage() {
        return SERVICE_PACKAGE;
    }

    @Override
    protected String getServiceClassName() {
        return SERVICE_CLASS;
    }

    @Override
    protected String getServiceAction() {
        return SERVICE_ACTION;
    }

    @Override
    protected ISdk asInterface(final IBinder binder) {
        return ISdk.Stub.asInterface(binder);
    }

    @Override
    protected boolean needStartService() {
        return false;
    }

    @Override
    protected String getLogTag() {
        return TAG;
    }

    @Override
    protected long getConnectionRetryCount() {
        return SERVICE_BIND_MAX_RETRY;
    }

    @Override
    protected long getConnectionRetryInterval() {
        return SERVICE_BIND_RETRY_INTERVAL_MS;
    }

    public static final String TAG = "CAR.SERVICE";

    public <T extends SdkManagerBase> T getService(@NonNull Class<T> serviceClass) {
        Log.i(TAG, "getService: "+serviceClass.getSimpleName());
        SdkManagerBase manager;
        // 涉及 managerMap 的操作，需要加锁
        synchronized (getLock()) {
            HashMap<Integer, SdkManagerBase> managerMap = getManagerCache();
            if (mService == null) {
                Log.w(TAG, "getService not working while car service not ready");
                return null;
            }
            int serviceType = getSystemServiceType(serviceClass);
            manager = managerMap.get(serviceType);
            if (manager == null) {
                try {
                    IBinder binder = mService.getService(serviceType);
                    if (binder == null) {
                        Log.w(TAG, "getService could not get binder for service:" + serviceType);
                        return null;
                    }
                    manager = createCarManagerLocked(serviceType, binder);
                    if (manager == null) {
                        Log.w(TAG, "getService could not create manager for service:" + serviceType);
                        return null;
                    }
                    managerMap.put(serviceType, manager);
                } catch (RemoteException e) {
                    handleRemoteExceptionFromService(e);
                }
            }
        }
        return (T) manager;
    }

    private int getSystemServiceType(@NonNull Class<?> serviceClass) {
        switch (serviceClass.getSimpleName()) {
            case "AudioManager":
                return SERVICE_AUDIO;
            case "InfoManager":
                return SERVICE_INFO;
            default:
                return -1;
        }
    }

    @Nullable
    private SdkManagerBase createCarManagerLocked(int serviceType, IBinder binder) {
        SdkManagerBase manager = null;
        switch (serviceType) {
            case SERVICE_AUDIO:
                manager = new AudioManager(this, binder);
                break;
            case SERVICE_INFO:
                manager = new InfoManager(this, binder);
                break;
            default:
                // Experimental or non-existing
                break;
        }
        return manager;
    }
}
