package com.wj.standardsdk.exception;

public class TransactionException extends UnsupportedOperationException {
    public TransactionException(Throwable cause, String msg, Object... args) {
        super(String.format(msg, args), cause);
    }
}
