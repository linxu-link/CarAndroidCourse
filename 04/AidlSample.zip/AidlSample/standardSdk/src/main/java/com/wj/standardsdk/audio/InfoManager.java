package com.wj.standardsdk.audio;

import android.os.IBinder;

import com.wj.standardsdk.base.SdkBase;
import com.wj.standardsdk.base.SdkManagerBase;

public class InfoManager extends SdkManagerBase {
    public InfoManager(SdkBase sdk, IBinder binder) {
        super(sdk);
    }

    @Override
    protected void onDisconnected() {

    }
}
