package com.wj.standardsdk.audio;

import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.RequiresPermission;

import com.wj.standardsdk.Sdk;
import com.wj.standardsdk.base.SdkBase;
import com.wj.standardsdk.base.SdkManagerBase;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 一个使用示例：音频管理类
 * @author linxu_link
 * @version 1.0
 */
public class AudioManager extends SdkManagerBase {

    private final IAudio mService;
    private final CopyOnWriteArrayList<AudioCallback> mCallbacks;

    public AudioManager(SdkBase sdk, IBinder binder) {
        super(sdk);
        mService = IAudio.Stub.asInterface(binder);
        mCallbacks = new CopyOnWriteArrayList<>();
    }

    private final IAudioCallback.Stub mCallbackImpl = new IAudioCallback.Stub() {
        @Override
        public void onAudioData(byte[] data, int length) throws RemoteException {
            for (AudioCallback callback : mCallbacks) {
                callback.onAudioData(data, length);
            }
        }
    };

    // 提示需要权限
    @RequiresPermission(Sdk.PERMISSION_AUDIO)
    public void play() {
        try {
            mService.play();
        } catch (RemoteException e) {
            Log.e(TAG, "play: " + e);
            handleRemoteExceptionFromService(e);
        }
    }

    public long getDuration() {
        try {
            return mService.getDuration();
        } catch (RemoteException e) {
            return handleRemoteExceptionFromService(e, 0);
        }
    }


    public void registerAudioCallback(AudioCallback callback) {
        Objects.requireNonNull(callback);
        if (mCallbacks.isEmpty()) {
            registerCallback();
        }
        mCallbacks.add(callback);
    }

    public void unregisterAudioCallback(AudioCallback callback) {
        Objects.requireNonNull(callback);
        if (mCallbacks.remove(callback) && mCallbacks.isEmpty()) {
            unregisterCallback();
        }
    }

    /************* 内部方法 *************/
    /**
     * 向服务端注册回调
     */
    private void registerCallback() {
        try {
            mService.registerAuidoCallback(mCallbackImpl);
        } catch (RemoteException e) {
            Log.e(TAG, "registerAudioCallback: " + e);
            handleRemoteExceptionFromService(e);
        }
    }

    /**
     * 取消注册回调
     */
    private void unregisterCallback() {
        try {
            mService.unregisterAudioCallback(mCallbackImpl);
        } catch (RemoteException e) {
            Log.e(TAG, "unregisterAudioCallback: " + e);
            handleRemoteExceptionFromService(e);
        }
    }

    @Override
    protected void onDisconnected() {

    }

    public abstract static class AudioCallback {

        public void onAudioData(byte[] data, int length) {

        }

    }

}
