package com.wj.standardserver.binder;

import android.os.RemoteException;

import com.wj.standardsdk.info.IInfo;

public class InfoBinder extends IInfo.Stub {
    @Override
    public void get() throws RemoteException {

    }
}
