package com.wj.standardserver.binder;

import static com.wj.standardsdk.Sdk.SERVICE_AUDIO;
import static com.wj.standardsdk.Sdk.SERVICE_INFO;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;

import com.wj.standardsdk.ISdk;

public class MainBinder extends ISdk.Stub {

    private final SparseArray<IBinder> mCache = new SparseArray<>();
    private final Object mLock = new Object();
    private final Context mContext;

    public MainBinder(final Context context) {
        mContext = context;
    }

    @Override
    public IBinder getService(final int serviceType) throws RemoteException {
        Log.i("TAG", "getService: serviceType = " + serviceType + ", UID: " + android.os.Process.myUid() + ", PID: " + android.os.Process.myPid());
        IBinder binder = mCache.get(serviceType);
        if (binder != null) {
            return binder;
        }
        synchronized (mLock) {
            switch (serviceType) {
                case SERVICE_AUDIO:
                    binder = new AudioBinder(mContext);
                    break;
                case SERVICE_INFO:
                    binder = new InfoBinder();
                    break;
            }
            mCache.put(serviceType, binder);
        }
        return binder;
    }


}
