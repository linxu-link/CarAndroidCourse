package com.wj.standardserver;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import com.wj.standardserver.binder.MainBinder;

public class StandardService extends Service {

    private MainBinder mBinder;

    @Override
    public void onCreate() {
        super.onCreate();
        mBinder = new MainBinder(getApplicationContext());
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(final Intent intent) {
        Log.i("TAG", "onUnbind: ");
        return super.onUnbind(intent);
    }
}
