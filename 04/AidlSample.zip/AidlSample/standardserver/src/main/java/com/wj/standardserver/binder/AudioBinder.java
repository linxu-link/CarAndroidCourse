package com.wj.standardserver.binder;

import android.content.Context;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.util.Log;

import com.wj.standardsdk.Sdk;
import com.wj.standardsdk.audio.IAudio;
import com.wj.standardsdk.audio.IAudioCallback;

public class AudioBinder extends IAudio.Stub {

    private final RemoteCallbackList<IAudioCallback> mCallbacks;
    private final Context mContext;

    public AudioBinder(Context context) {
        mContext = context;
        mCallbacks = new RemoteCallbackList<>();
    }

    @Override
    public void play() throws RemoteException {
        Log.i("TAG", "play() called, UID: " + android.os.Process.myUid() + ", PID: " + android.os.Process.myPid());
        mContext.enforceCallingPermission(Sdk.PERMISSION_AUDIO, "no permission");
    }

    @Override
    public long getDuration() throws RemoteException {
        Log.i("TAG", "getDuration() called, UID: " + android.os.Process.myUid() + ", PID: " + android.os.Process.myPid());
        mContext.enforceCallingPermission(Sdk.PERMISSION_AUDIO, "no permission");
        return 1222;
    }

    @Override
    public void registerAuidoCallback(final IAudioCallback callback) throws RemoteException {
        mContext.enforceCallingPermission(Sdk.PERMISSION_AUDIO, "no permission");
        mCallbacks.register(callback);
    }

    @Override
    public void unregisterAudioCallback(final IAudioCallback callback) throws RemoteException {
        mContext.enforceCallingPermission(Sdk.PERMISSION_AUDIO, "no permission");
        mCallbacks.unregister(callback);
    }
}
