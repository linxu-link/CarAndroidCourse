package com.wj.client;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Debug;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;

import com.wj.sdk.ICalculator;
import com.wj.sdk.bean.Sample;
import com.wj.sdk.bean.Sample2;
import com.wj.sdk.binderpool.IHvac;
import com.wj.sdk.binderpool.IVehicle;
import com.wj.sdk.listener.ICalculatorListener;

import java.io.File;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private ICalculator mCalculator;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mCalculator = ICalculator.Stub.asInterface(iBinder);
            transferCustomType();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindToService();

    }

    private void bindToService() {
        Intent intent = new Intent();
        intent.setAction("com.example.aidl.ServerService");
        intent.setClassName("com.wj.server", "com.wj.server.ServerService");
        boolean suc = bindService(intent, serviceConnection, BIND_AUTO_CREATE);
        Log.i(TAG, "bindToService: " + suc);
    }

    // AIDL 基本使用方式
    private void calculate(final char operator, final int num1, final int num2) {
        try {
            int result = 0;
            switch (operator) {
                case '+':
                    result = mCalculator.add(num1, num2);
                    break;
                case '-':
                    result = mCalculator.subtract(num1, num2);
                    break;
                case '*':
                    result = mCalculator.multiply(num1, num2);
                    break;
                case '/':
                    result = mCalculator.divide(num1, num2);
                    break;
            }
            Log.i(TAG, "calculate result : " + result);
        } catch (RemoteException exception) {
            Log.i(TAG, "calculate: " + exception);
        }
    }

    // 问题1、2 - 传递自定义类型、数据流向
    private void transferCustomType() {
        try {
            // 传递自定义类型
            Sample sample = new Sample();
            sample.setNum(12);

            // 打开 assets 下的link.txt取出内容，保存为字符串
            InputStream inputStream = getAssets().open("link.txt");
            byte[] bytes = new byte[1024 * 1600];
            inputStream.read(bytes);
            sample.setStr(new String(bytes));
            Log.e(TAG, "transferCustomType size:  " + bytes.length);
            mCalculator.optionParcel(sample);


        } catch (Exception exception) {
            Log.i(TAG, "transferCustomType: " + exception);
        }
    }

    // 计算一个对象在内存中的大小
    private long getObjectSize(Object obj) {
        long size = 0;
        try {
            // getNativeHeapAllocatedSize 获取当前进程的堆内存大小
            size = android.os.Debug.getNativeHeapAllocatedSize();
            Log.e(TAG, "getObjectSize: " + size);
            return size;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // 问题3 - 传递Bundle
    private void transferBundle() {
        try {
            // 传递Bundle
            Bundle bundle = new Bundle();
            Sample sample = new Sample();
            sample.setNum(12);
            bundle.putParcelable("sample", sample);

            Sample2 sample2 = new Sample2();
            sample2.setNum(12);
            bundle.putSerializable("sample2", sample2);
            mCalculator.optionBundle(bundle);
        } catch (RemoteException exception) {
            Log.i(TAG, "transferBundle: " + exception);
        }
    }

    // 问题4 - 传输大文件
    private void transferData() {
        try {
            // file.iso 是要传输的文件，位于app的缓存目录下，约3.5GB
            ParcelFileDescriptor fileDescriptor = ParcelFileDescriptor.open(new File(getCacheDir(), "file.iso"), ParcelFileDescriptor.MODE_READ_ONLY);
            // 调用AIDL接口，将文件描述符的读端 传递给 接收方
            mCalculator.transactFileDescriptor(fileDescriptor);
            fileDescriptor.close();

            /******** 下面的方法也可以实现文件传输，「接收端」不需要任何修改，原理是一样的 ********/
//        createReliablePipe 创建一个管道，返回一个 ParcelFileDescriptor 数组，
//        数组中的第一个元素是管道的读端，
//        第二个元素是管道的写端
//            ParcelFileDescriptor[] pfds = ParcelFileDescriptor.createReliablePipe();
//            ParcelFileDescriptor pfdRead = pfds[0];
//
//            // 调用AIDL接口，将管道的读端传递给 接收端
//            options.transactFileDescriptor(pfdRead);
//
//            ParcelFileDescriptor pfdWrite = pfds[1];
//
//            // 将文件写入到管道中
//            byte[] buffer = new byte[1024];
//            int len;
//            try (
//                    // file.iso 是要传输的文件，位于app的缓存目录下
//                    FileInputStream inputStream = new FileInputStream(new File(getCacheDir(), "file.iso"));
//                    ParcelFileDescriptor.AutoCloseOutputStream autoCloseOutputStream = new ParcelFileDescriptor.AutoCloseOutputStream(pfdWrite);
//            ) {
//                while ((len = inputStream.read(buffer)) != -1) {
//                    autoCloseOutputStream.write(buffer, 0, len);
//                }
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        transferData();
    }

    // 问题5 - oneway
    private void callOneway() {
        try {
            mCalculator.optionOneway(12);
            Log.i(TAG, "callOneway: ");
        } catch (RemoteException exception) {
            Log.i(TAG, "callOneway: " + exception);
        }
    }

    // 问题6 - RemoteCallback
    private void callRemote() {
        try {
            ICalculatorListener.Stub listener = new ICalculatorListener.Stub() {
                @Override
                public void callback(final String result) throws RemoteException {
                    Log.i(TAG, "callback: " + result);
                }
            };
            mCalculator.registerListener(listener);

//            Thread.sleep(3000);
//            mCalculator.unregisterListener(listener);
//            Log.i(TAG, "callRemote: ");

        } catch (RemoteException exception) {
            Log.i(TAG, "callRemote: " + exception);
        }
    }

    public static final int TYPE_HAVC = 1;
    public static final int TYPE_VEHICLE = 2;

    // 问题7 - Binder连接池
    private void callBinderPool() {
        try {
            IBinder binder = mCalculator.queryBinder(TYPE_HAVC);
            IHvac hvac = IHvac.Stub.asInterface(binder);
            // Hvac 提供的aidl接口
            hvac.basicTypes(1, 2, true, 3.0f, 4.0, "5");

            binder = mCalculator.queryBinder(TYPE_VEHICLE);
            IVehicle vehicle = IVehicle.Stub.asInterface(binder);
            // Vehicle 提供的aidl接口
            vehicle.basicTypes(1, 2, true, 3.0f, 4.0, "5");

        } catch (RemoteException exception) {
            Log.i(TAG, "callBinderPool: " + exception);
        }
    }

    // 问题9 - 权限
    @RequiresPermission(PERMISSION)
    private void callPermission() {
        try {
            if (checkPermission()) {
                Log.i(TAG, "callPermission: 有权限");
                mCalculator.optionPermission(1);
            } else {
                Log.i(TAG, "callPermission: 没有权限");
            }
        } catch (RemoteException exception) {
            Log.i(TAG, "callPermission: " + exception);
        }
    }

    /**
     * 检查应用自身是否有权限
     *
     * @return true 有权限，false 没有权限
     */
    private boolean checkPermission() {
        return checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    public static final String PERMISSION = "com.wj.permission";

}