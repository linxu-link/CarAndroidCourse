package com.wj.sdk.bean;

import java.io.Serializable;

public class Sample2 implements Serializable {

    private int mNum;

    public int getNum() {
        return mNum;
    }

    public void setNum(final int num) {
        mNum = num;
    }
}
